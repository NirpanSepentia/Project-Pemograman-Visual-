﻿Public Class ProgramChangeKurs
    Private Sub CHANGEKURS_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Rupiah_TextChanged(sender As Object, e As EventArgs) Handles Rupiah.TextChanged
        Label4.Text = "Rp." & Val(Dollar.Text) * Val(Rupiah.Text)

    End Sub

    Private Sub ProgramChangeKurs_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class

